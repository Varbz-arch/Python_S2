import pandas as pd
my_datastr=pd.Series({"Mahindra":45,"BMW":22})
print(my_datastr)
