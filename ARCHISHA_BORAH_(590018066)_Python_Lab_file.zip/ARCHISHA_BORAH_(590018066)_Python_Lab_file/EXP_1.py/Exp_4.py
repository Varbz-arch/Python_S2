#Take two variable a and b. Assign your first name and last name. Print your Name 
#after adding your First name and Last name together.

a='ARCHISHA '
b='BORAH'
print (a+b)