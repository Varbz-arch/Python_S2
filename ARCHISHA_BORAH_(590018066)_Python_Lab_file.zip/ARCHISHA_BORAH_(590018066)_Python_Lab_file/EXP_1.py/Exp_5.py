#Declare three variables, consisting of your first name, your last name and 
#Nickname. Write a  program that prints out your first name, then your nickname in 
#parenthesis and then your last name.   
#Example output : George ( woody ) Washington. 

a='ARCHISHA'
b='BORAH'
c='VARBEE'
print(f'{a} ({c}) {b}')