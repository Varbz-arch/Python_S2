#1
a='Hello Everyone!!!'
b='Hello'
c='World'
name='Arun'
dob='22/06/2005'
print(f'1){a}\n2){b}\n{c}\n3){b}\n\t{c}')
print(f"4){name}'s date of birth is {dob}")

#2
x='Hello'
print(f'{x}')

#3
name='Archisha'
n=22
f=0.05
list=[1,2,'hola',0.75]
print('name=%s'%name)
print('int n=%d'%n)
print('float f=%d'%f)
print(f'list={list}')

#4
a='ARCHISHA '
b='BORAH'
print (a+b)

#5
a='ARCHISHA'
b='BORAH'
c='VARBEE'
print(f'{a} ({c}) {b}')

#6
NAME='ARCHISHA BORAH'
SAP_ID='590018066'
DATE_OF_BIRTH='22/06/2005'
ADDRESS='UPES\n\tBidholi Camous\n\tPincode: 248007'
PROGRAMME='CSE'
SEM='2'
print(f'NAME={NAME}\n SAP ID={SAP_ID}\n DATE OF BIRTH={DATE_OF_BIRTH}')
print(f'ADDRESS={ADDRESS}\n PROGRAMME={PROGRAMME}\n SEM={SEM}')