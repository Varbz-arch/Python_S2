#Declare and assign values to suitable variables and print in the following way : 
#NAME : NIKUNJ BANSAL   
#SAP ID : 500069944 
#DATE OF BIRTH : 13 Oct 1999 
#ADDRESS : UPES 
#          Bidholi Campus 
#          Pincode : 248007 
#Programme : AI & ML                                                                                       
#Semester : 2 

NAME='ARCHISHA BORAH'
SAP_ID='590018066'
DATE_OF_BIRTH='22/06/2005'
ADDRESS='UPES\n\tBidholi Camous\n\tPincode: 248007'
PROGRAMME='CSE'
SEM='2'
print(f'NAME={NAME}\n SAP ID={SAP_ID}\n DATE OF BIRTH={DATE_OF_BIRTH}')
print(f'ADDRESS={ADDRESS}\n PROGRAMME={PROGRAMME}\n SEM={SEM}')