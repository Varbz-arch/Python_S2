'''Write Python programs to print strings in the given manner: 
a)   Hello Everyone !!! 
b)   Hello 
     World 
c)   Hello 
              World 
d) ‘ Rohit’ s date of birth is 12\05\1999’ '''

a='Hello Everyone!!!'
b='Hello'
c='World'
name='Arun'
dob='22/06/2005'
print(f'1){a}\n2){b}\n{c}\n3){b}\n\t{c}')
print(f"4){name}'s date of birth is {dob}")