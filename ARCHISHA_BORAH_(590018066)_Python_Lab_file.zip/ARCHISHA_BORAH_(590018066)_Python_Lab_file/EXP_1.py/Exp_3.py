# Take different data types and print values using print function.

name='Archisha'
n=22
f=0.05
list=[1,2,'hola',0.75]
print('name=%s'%name)
print('int n=%d'%n)
print('float f=%d'%f)
print(f'list={list}')