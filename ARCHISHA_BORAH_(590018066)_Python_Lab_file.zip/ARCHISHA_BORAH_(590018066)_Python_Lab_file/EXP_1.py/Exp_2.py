#Declare a string variable called x and assign it the value “Hello”. 
#Print out the value of X

x='Hello'
print(f'{x}')