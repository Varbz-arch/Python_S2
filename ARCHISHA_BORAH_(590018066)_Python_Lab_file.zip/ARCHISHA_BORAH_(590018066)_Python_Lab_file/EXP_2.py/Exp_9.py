#Write a program to find sum of first n natural numbers.

n = int(input("Enter a number n: "))
sum = (n * (n + 1)) // 2
print(f"The sum of the first {n} natural numbers is: {sum}")
