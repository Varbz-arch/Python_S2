# Using membership operator find whether a given character is in a string. 

NAME='AVINASH'
if 'A' in NAME:
    print('EXISTS')
else:
    print('OOPS! TRY AGAIN')
