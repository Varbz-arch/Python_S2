''' Declare these variables (x, y and z) as integers. Assign a value of 9 to x, Assign 
a value of 7 to y, perform addition, multiplication, division and subtraction on 
these two variables and Print out the result.''' 

x = 9
y = 7
addition = x + y
subtraction = x - y
multiplication = x * y
division = x // y  # //-> integer division  /-> float division
print("Addition:", addition)
print("Subtraction:", subtraction)
print("Multiplication:", multiplication)
print("Division:", division)
