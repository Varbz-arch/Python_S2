#Write functions to explain mentioned concepts: 
#a. Keyword argument 
def sum(x, y=4):
    return x+y
answer=sum(4)
print("Answer is: ", answer)