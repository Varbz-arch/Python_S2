# Write a lambda function which gives tuple of max and min from a list.

find_max = lambda lst: (max(lst))
find_min = lambda lst: (min(lst))
print(find_max([10, 6, 8, 90, 12, 56]),find_min([10, 6, 8, 90, 12, 56])) 
